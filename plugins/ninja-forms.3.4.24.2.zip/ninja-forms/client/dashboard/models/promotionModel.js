define( [], function() {
  var model = Backbone.Model.extend( {
    defaults: {
      id: '',
      content: '',
    },

    initialize: function() {
      /* ... */
    },

  } );

  return model;
} );
